﻿
namespace forma_grafica_desprendible
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.textcontraseña = new System.Windows.Forms.Label();
            this.password = new System.Windows.Forms.TextBox();
            this.buttoncontraseña = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textcontraseña
            // 
            this.textcontraseña.AutoSize = true;
            this.textcontraseña.Font = new System.Drawing.Font("Arial Narrow", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textcontraseña.ForeColor = System.Drawing.Color.DarkRed;
            this.textcontraseña.Location = new System.Drawing.Point(281, 97);
            this.textcontraseña.Name = "textcontraseña";
            this.textcontraseña.Size = new System.Drawing.Size(226, 31);
            this.textcontraseña.TabIndex = 0;
            this.textcontraseña.Text = "ingresar contraseña";
            // 
            // password
            // 
            this.password.Location = new System.Drawing.Point(246, 181);
            this.password.Name = "password";
            this.password.PasswordChar = '*';
            this.password.Size = new System.Drawing.Size(301, 20);
            this.password.TabIndex = 1;
            this.password.TextChanged += new System.EventHandler(this.boxcontraseña_TextChanged);
            // 
            // buttoncontraseña
            // 
            this.buttoncontraseña.Location = new System.Drawing.Point(357, 235);
            this.buttoncontraseña.Name = "buttoncontraseña";
            this.buttoncontraseña.Size = new System.Drawing.Size(75, 23);
            this.buttoncontraseña.TabIndex = 2;
            this.buttoncontraseña.Text = "ingresar";
            this.buttoncontraseña.UseVisualStyleBackColor = true;
            this.buttoncontraseña.Click += new System.EventHandler(this.buttoncontraseña_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buttoncontraseña);
            this.Controls.Add(this.password);
            this.Controls.Add(this.textcontraseña);
            this.Name = "Form1";
            this.Text = "contraseña";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label textcontraseña;
        private System.Windows.Forms.TextBox password;
        private System.Windows.Forms.Button buttoncontraseña;
    }
}

